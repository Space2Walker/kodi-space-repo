# plugin.program.dnsleaktest
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black) ![](https://github.com/Space2Walker/plugin.program.dnsleaktest/workflows/Kodi-Addon-Check/badge.svg)
## DNS leak Test Addon for KODI
Compatible to [Kodi](https://kodi.tv/)-19.0 and above.

This Addon performs a DNS leak test on [bash.ws](https://bash.ws/dnsleak)!

The Basic Code comes from [macvk](https://github.com/macvk/dnsleaktest).

This Addon should work on all Platorms.
