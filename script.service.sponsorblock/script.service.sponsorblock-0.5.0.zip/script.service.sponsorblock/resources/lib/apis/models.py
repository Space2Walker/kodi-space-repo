from collections import namedtuple


NotificationPayload = namedtuple("NotificationPayload", ("video_id", "unlisted"))
